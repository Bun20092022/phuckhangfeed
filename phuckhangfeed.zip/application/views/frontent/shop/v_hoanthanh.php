<section class="inner_page_breadcrumb">
   <div class="container">
      <div class="row">
         <div class="col-xl-6">
            <div class="breadcrumb_content">
               <ol class="breadcrumb">
                  <li class="breadcrumb-item"><a href="<?= base_url(); ?>">Trang chủ</a></li>
                  <li class="breadcrumb-item active" aria-current="page">Đặt hàng thành công</li>
               </ol>
            </div>
         </div>
      </div>
   </div>
</section>
<!-- Main Blog Post Content -->
	<section class="blog_post_container pt30" style="padding-bottom: 300px;">
		<div class="container">
      <div class="row">
       
         <div class="col-md-12 text-center" style="padding-bottom: 300px;">
            <h2>Cảm ơn bạn đã đặt hàng thành công</h2>
            <h3><a href="<?= base_url(); ?>">Tiếp tục mua sắm!!!</a></h3>
         </div>

      </div>
		</div>