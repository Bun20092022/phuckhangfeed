<header id="header" class="fixed-top">
 <div class="container d-flex align-items-center">
  <h1 class="logo me-auto"><a href="<?= base_url(); ?>"><img src="<?php $this->Model_info->get_logoheader(); ?>"></a></h1>
  <?php $this->load->view('frontent/extendtion/v_menu'); ?>
</div>
</header><!-- End Header -->               