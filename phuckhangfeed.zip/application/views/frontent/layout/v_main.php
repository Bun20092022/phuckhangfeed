<?php $this->load->view('frontent/layout/v_m_header'); ?>
<main id="main">
	<?php $this->load->view($template); ?>
</main><!-- End #main -->
<?php $this->load->view('frontent/layout/v_m_footer'); ?>
