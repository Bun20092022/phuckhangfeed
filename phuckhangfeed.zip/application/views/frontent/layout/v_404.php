<!-- content  -->   
<div class="content full-height">
    <div class="body-bg">
        <div class="bg"  data-bg="public/frontent/assets/images/bg/1.jpg"></div>
        <div class="overlay"></div>
    </div>
    <!--error-wrap-->
    <div class="error-wrap fl-wrap">
        <div class="container">
            <h2>404</h2>
            <p>Rất tiếc, không thể tìm thấy Trang bạn đang tìm kiếm.</p>
            <div class="clearfix"></div>
            <div class="dots-separator fl-wrap"><span></span></div>
            <a href="<?= base_url(); ?>" class="btn">Trở lại trang chủ <i class="fal fa-long-arrow-right"></i></a>
            <div class="section-dec sec-dec_top"></div>
            <div class="section-dec sec-dec_bottom"></div>
        </div>
    </div>
    <!--error-wrap end-->                                    
</div>
                <!-- content end  -->