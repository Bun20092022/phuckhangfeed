  <?php $this->load->view('frontent/extendtion/v_footer'); ?>
  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="<?= base_url(); ?>public/frontent/assets/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="<?= base_url(); ?>public/frontent/assets/vendor/aos/aos.js"></script>
  <script src="<?= base_url(); ?>public/frontent/assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="<?= base_url(); ?>public/frontent/assets/vendor/bootstrap/js/bootstrap.min.js"></script>
  <script src="<?= base_url(); ?>public/frontent/assets/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="<?= base_url(); ?>public/frontent/assets/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="<?= base_url(); ?>public/frontent/assets/js/main.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.3/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>