<div class="row">
   <div class="col-md-12 grid-margin stretch-card">
      <div class="card">
         <div class="card-body">
            <h6 class="card-title">Thêm quản lý website</h6>
            <form action="" method="post">
               <div class="mb-3">
                  <label class="form-label">Thêm website</label>
                  <input type="text" class="form-control" name="website" id="name" required>
               </div>
               <button class="btn btn-primary" type="submit" name="add">Thêm thông tin</button>
            </form>
         </div>
      </div>
   </div>
</div>
