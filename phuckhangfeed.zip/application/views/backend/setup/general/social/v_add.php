<div class="row">
   <div class="col-md-12 grid-margin stretch-card">
      <div class="card">
         <div class="card-body">
            <h6 class="card-title">Thêm quản lý Social</h6>
            <form action="" method="post">
               <div class="row">
                  <div class="col-md-6 mt-3">
                     <label class="form-label">Thêm tên Social</label>
                     <input type="text" class="form-control" name="name_social" required>
                  </div>
                  <div class="col-md-6 mt-3">
                     <label class="form-label">Thêm class Social</label>
                     <input type="text" class="form-control" name="class_social">
                  </div>
                  <div class="col-md-12 mt-3">
                     <label class="form-label">Thêm link liên kết Social</label>
                     <input type="text" class="form-control" name="link_socical">
                  </div>
                  <div class="col-md-6 mt-3">
                     <label class="form-label">Thứ tự</label>
                     <input type="text" class="form-control" name="num_social">
                  </div>
                  <div class="col-md-12 mt-3">
                     <button class="btn btn-primary btn-xs" type="submit" name="add">Thêm thông tin</button>
                  </div>
               </div>
            </form>
         </div>
      </div>
   </div>
</div>
