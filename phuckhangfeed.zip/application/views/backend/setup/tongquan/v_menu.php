
<div class="list-group">
  <a href="backend/setup/general/main/infowebsite" class="list-group-item list-group-item-action <?php if(isset($active_sub) && $active_sub == 3){ echo 'active'; } ?>"><i class="la la-hand-o-right text-primary me-2"></i>Tổng quan website</a>
  <a href="backend/setup/general/website" class="list-group-item list-group-item-action <?php if(isset($active_sub) && $active_sub == 1){ echo 'active'; } ?>"><i class="la la-hand-o-right text-primary me-2"></i>Danh sách website</a>
  <a href="backend/setup/general/language" class="list-group-item list-group-item-action <?php if(isset($active_sub) && $active_sub == 2){ echo 'active'; } ?>"><i class="la la-hand-o-right text-primary me-2"></i>Ngôn ngữ website</a>
  <a href="backend/setup/general/social" class="list-group-item list-group-item-action <?php if(isset($active_sub) && $active_sub == 4){ echo 'active'; } ?>"><i class="la la-hand-o-right text-primary me-2"></i>Các trang mạng xã hội</a>
  <a href="backend/setup/general/lang_website" class="list-group-item list-group-item-action <?php if(isset($active_sub) && $active_sub == 5){ echo 'active'; } ?>"><i class="la la-hand-o-right text-primary me-2"></i>Ngôn ngữ trên Website</a>
  <a href="backend/setup/general/extend_website" class="list-group-item list-group-item-action <?php if(isset($active_sub) && $active_sub == 6){ echo 'active'; } ?>"><i class="la la-hand-o-right text-primary me-2"></i>Tính năng mở rộng</a>
  <a href="backend/setup/general/lang_menu" class="list-group-item list-group-item-action <?php if(isset($active_sub) && $active_sub == 7){ echo 'active'; } ?>"><i class="la la-hand-o-right text-primary me-2"></i>Ngôn ngữ cho menu Website</a>
</div>