<div class="row">
   <div class="col-md-12 grid-margin stretch-card">
      <div class="card">
         <div class="card-body">
            <form action="" method="post">
               <div class="form-group">
                  <label for="exampleInputText1">Tên thuộc tính</label>
                  <textarea class="form-control" rows="25">
                     

                  </textarea>
               </div>
               <button class="btn btn-primary" type="submit" name="themthongtin">Thêm thông tin</button>
         </div>
      </div>
   </div>
</div>
</form>