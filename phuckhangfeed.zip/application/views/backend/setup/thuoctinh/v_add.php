<div class="row">
   <div class="col-md-12 grid-margin stretch-card">
      <div class="card">
         <div class="card-body">
            <form action="" method="post">
               <div class="form-group">
                  <label for="exampleInputText1">Tên thuộc tính</label>
                  <input type="text" class="form-control" name="thuoctinh">
               </div>
               <div class="form-group">
                  <label for="exampleInputEmail3">Mã Code (Không được trùng với các mã code đã có trong thuộc tính)</label>
                  <input type="text" class="form-control" name="code">
               </div>
               <button class="btn btn-primary" type="submit" name="themthongtin">Thêm thông tin</button>
         </div>
      </div>
   </div>
</div>
</form>