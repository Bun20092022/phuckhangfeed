<pre class="brush: xml; title: ; notranslate" title="">
<!-- Chú ý chuyển mã code HTML về kí tự đặc biệt -->
&lt;script src=&quot;https://code.jquery.com/jquery-latest.js&quot;&gt;&lt;/script&gt;&#10;
</pre>