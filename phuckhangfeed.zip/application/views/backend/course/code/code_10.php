Chúng ta có thể download phiên bản mới nhất tại: <a href="http://jquery.com/download/">http://jquery.com/download/</a>, sử dụng tag <script> kết nối file jquery nội dung như sau:
<pre class="brush: xml; title: ; notranslate" title="">
<!-- Chú ý chuyển mã code HTML về kí tự đặc biệt -->
&lt;!DOCTYPE HTML&gt;&#10;&lt;html&gt;&#10;&lt;head&gt;&#10;&lt;meta charset=&quot;utf-8&quot;&gt;&#10;&lt;title&gt;Ti&ecirc;u &#273;&#7873;&lt;/title&gt;&#10;&lt;script src=&quot;jquery.js&quot;&gt;&lt;/script&gt;&#10;&lt;script&gt;&#10;//Code jquery vi&#7871;t &#7903; &#273;&acirc;y...&#10;&lt;/script&gt;&#10;&lt;/head&gt;&#10;&#10;&lt;body&gt;&#10;//Code html vi&#7871;t &#7903; &#273;&acirc;y...&#10;&lt;/body&gt;&#10;&lt;/html&gt;
</pre>