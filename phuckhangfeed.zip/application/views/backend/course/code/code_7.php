<pre class="brush: xml; title: ; notranslate" title="">
<!-- Chú ý chuyển mã code HTML về kí tự đặc biệt -->

</pre>
