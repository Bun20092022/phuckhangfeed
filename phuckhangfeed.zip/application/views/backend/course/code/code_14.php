1
<div class="highlight">
   <pre>
   	<code class="language-html" data-lang="html">
      int main()
      {
          std::cout << "Hello, World!" << std::endl;
          return 0;
      }
    </code>
   </pre>
</div>