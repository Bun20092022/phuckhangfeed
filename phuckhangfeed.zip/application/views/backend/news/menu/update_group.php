<div class="row">
      <div class="col-md-12 grid-margin stretch-card">
         <div class="card">
            <div class="card-body">
               <h6 class="card-title">Nội dung menu</h6>
               <form action="" method="post">
                  <div class="mb-3">
                     <label class="form-label">Tên menu</label>
                     <input type="text" class="form-control" name="menu_group" required value="<?= $view['menu_group']; ?>">
                  </div>
                  <button class="btn btn-primary" type="submit" name="add">Chỉnh sửa Menu</button>
               </div>
            </div>
         </div> 
      </div>
   </form>
