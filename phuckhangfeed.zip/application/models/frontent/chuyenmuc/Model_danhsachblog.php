<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Model_danhsachblog extends CI_Model {

	

}

/* End of file Model_danhsachblog.php */
/* Location: ./application/models/frontent/chuyenmuc/Model_danhsachblog.php */